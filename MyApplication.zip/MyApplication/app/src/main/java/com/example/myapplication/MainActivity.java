package com.example.flipgame;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import com.example.myapplication.R;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final Random random = new Random();

    private Imageview coin;

    private Button flip;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coin = (ImageView) findViewById(R.id.coin_img);
        flip = (Button) findViewById(R.id.flip_btn);

        flip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                flipcoin();
            }
        });
    }

    Private void flipCoin() {
        Animation fadeOut = new AlphaAnimation(1,0);
        fadeOut.setInterpolator(new DecelerateInterpolator());
        fadeOut.setDuration(1000);
        fadeOut.FillAfter(true);
        fadeOut.setAnimationListener(new Animation animation) {
    }
    @Override
            public void onAnimationEnd(Animation animation) {
            coin.setImageResource(random.next.Float() > 0.5f ? R.drawable.pound_tails :R.drawable.)

                    Animation
        }
}